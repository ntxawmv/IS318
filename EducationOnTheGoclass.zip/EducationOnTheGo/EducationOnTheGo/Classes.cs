﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EducationOnTheGo
{
    public class Classes
    {
        private int ID;
        private Dictionary<int, String> studentList;
        private double classAverage;
        private Instructor assingedInstructor;

        public int ID1 { get => ID; set => ID = value; }
        public Dictionary<int, string> StudentList { get => studentList; set => studentList = value; }
        public double ClassAverage { get => classAverage;}
        public Instructor AssingedInstructor { get => assingedInstructor;}

        public void averageGrades()
        {
            double avg = 0.0;

            classAverage = avg;
        }
    }
}