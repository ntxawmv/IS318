﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EducationOnTheGo
{
    public class School
    {
        private int ID;
        private Dictionary<int, string> teacherList;
        private Dictionary<int, string> studentList;
        private Dictionary<int, string> classList;
        private string Classes;

        public int GetID()
        {
            return GetID();
        }

        public void SetID(int value)
        {
            SetID(value);
        }

        public Dictionary<int, string> teacherlist { get => teacherList; set => teacherList = value; }
        public Dictionary <int, string> StudentList { get => studentList; set => studentList = value; }
        public Dictionary <int, string> ClassList { get => classList; set => classList = value; }
        public void AddTeacher (int staffID, string name)
        {
            Dictionary<int, string> teacherList = new Dictionary<int, string>();
            teacherList.Add(100, "Mary Hawthorn");
        }

        private Dictionary<T1, T2> newDictionary<T1, T2>()
        {
            throw new NotImplementedException();
        }
        public void AddStudent(int studentID, string name)
        {
            Dictionary<int, string> studentList = new Dictionary<int, string>();
            studentList.Add(0084576, "Jane Martin");
        }

        private Dictionary<T1, T2> NewDictionary<T1, T2>()
        {
            throw new NotImplementedException();
        }

        public void assignClass(int ID, string name)
        {
            Dictionary<int, string> classList = new Dictionary<int, string>();
            classList.Add(100012, "Essentials to IS");
        }
    }
}