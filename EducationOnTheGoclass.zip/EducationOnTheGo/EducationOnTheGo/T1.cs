﻿namespace EducationOnTheGo
{
    internal class T1
    {
    }
}