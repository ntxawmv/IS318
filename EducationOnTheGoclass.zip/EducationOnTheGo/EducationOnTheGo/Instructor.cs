﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EducationOnTheGo
{
    public class Instructor
    {
        //Instructors Employee ID
        private int ID;
        //Instructors Name
        private String Name;
        //Instructors class list; to be updated by the administration
        private List<String> classList;

        public int ID1 { get => ID; set => ID = value; }
        public string Name1 { get => Name; set => Name = value; }
        public List<string> ClassList { get => classList; set => classList = value; }
        



    }
}