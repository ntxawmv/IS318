﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SQLite;

namespace EducationOnTheGo
{
    class LoginTable
    {
        [PrimaryKey, AutoIncrement, Column("_Id")]

        public int id { get; set; } // AutoIncrement and set primarykey  

        [MaxLength(25)]

        public string username { get; set; }

        [MaxLength(15)]

        public string password { get; set; }

        public string accountType { get; set; }

        public string firstName { get; set; }

        public string lastName { get; set; }

        public string school { get; set; }
    }
}