﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SQLite;

namespace EducationOnTheGo
{
    [Activity(Label = "LoginStuActivity")]
    public class LoginStuActivity : Activity
    {
        TextView editText1;
        TextView editText2;
        Button btnSignIn;
        Button btnRegister;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.LoginStu);

            editText1 = FindViewById<TextView>(Resource.Id.editText1);
            editText2 = FindViewById<TextView>(Resource.Id.editText2);
            btnSignIn = FindViewById<Button>(Resource.Id.btnSignIn);
            btnRegister = FindViewById<Button>(Resource.Id.btnRegister);

            btnSignIn.Click += BtnSignIn_Click;
            btnRegister.Click += BtnRegister_Click;
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            var intent = new Intent(this, typeof(RegisterActivity));
            StartActivity(intent);
            Finish();
        }

        private void BtnSignIn_Click(object sender, EventArgs e)
        {
            try
            {
                string dpPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "user.db3"); //Call Database  
                var db = new SQLiteConnection(dpPath);
                var data = db.Table<LoginTable>(); //Call Table  
                var data1 = data.Where(x => x.username == editText1.Text && x.password == editText2.Text).FirstOrDefault(); //Linq Query  
                if (data1 != null)
                {
                    Toast.MakeText(this, "Login Success", ToastLength.Short).Show();
                    var intent = new Intent(this, typeof(HomeActivity));
                    intent.PutExtra("accountType", "Student");
                    intent.PutExtra("username", editText1.Text);
                    StartActivity(intent);
                    Finish();
                }
                else
                {
                    Toast.MakeText(this, "Username or Password invalid", ToastLength.Short).Show();
                }
            }
            catch (Exception ex)
            {
                Toast.MakeText(this, ex.ToString(), ToastLength.Short).Show();
            }
            
        }
    }
}