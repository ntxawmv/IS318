﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace EducationOnTheGo
{
    [Activity(Label = "HomeActivity")]
    public class HomeActivity : Activity
    {
        
        Button btnGrades;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            String text = Intent.GetStringExtra("accountType");
            String username = Intent.GetStringExtra("username");
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.Home);

            btnGrades = FindViewById<Button>(Resource.Id.btnGrades);

            if (text.Equals("Teacher"))
            {
                btnGrades.Click += delegate (object sender, EventArgs e) { btnGradesTeach_Click(sender, e, username); };
            }
            else
            {
                btnGrades.Click += delegate (object sender, EventArgs e) { btnGradesStudent_Click(sender, e, username); };
            }
            

        }

        private void btnGradesStudent_Click(object sender, EventArgs e, string username)
        {
            var intent = new Intent(this, typeof(GradesStudentActivity));
            var bundle = new Bundle();
            intent.PutExtra("accountType", "Student");
            intent.PutExtra("username", username);
            StartActivity(intent);
            Finish();
        }

        private void btnGradesTeach_Click(object sender, EventArgs e, string username)
        {
            var intent = new Intent(this, typeof(GradesTeachActivity));
            var bundle = new Bundle();
            intent.PutExtra("accountType", "Teacher");
            intent.PutExtra("username", username);
            StartActivity(intent);
            Finish();
        }

        private void BtnGradesStu_Click(object sender, EventArgs e)
        {
            
            throw new NotImplementedException();
        }
    }
}