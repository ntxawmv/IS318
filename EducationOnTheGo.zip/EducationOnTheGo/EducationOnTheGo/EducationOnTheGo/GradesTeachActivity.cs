﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace EducationOnTheGo
{
    [Activity(Label = "GradesTeachActivity")]
    public class GradesTeachActivity : Activity
    {
       
        Button btnAddGrade;
        Button btnBack;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            String text = Intent.GetStringExtra("accountType");
            String username = Intent.GetStringExtra("username");
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.GradesTeach);

            btnAddGrade = FindViewById<Button>(Resource.Id.btnAddGrade);
            btnBack = FindViewById<Button>(Resource.Id.btnBack);

            btnBack.Click += delegate (object sender, EventArgs e) { BtnBack_Click(sender, e, username); };
        }

        private void BtnBack_Click(object sender, EventArgs e, String username)
        {
            var intent = new Intent(this, typeof(HomeActivity));
            var bundle = new Bundle();
            intent.PutExtra("accountType", "Teacher");
            intent.PutExtra("username", username);
            StartActivity(intent);
            Finish();
        }
    }
}