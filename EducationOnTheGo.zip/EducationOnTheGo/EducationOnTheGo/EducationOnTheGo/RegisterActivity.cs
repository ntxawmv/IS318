﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SQLite;

namespace EducationOnTheGo
{
    [Activity(Label = "SchoolActivity")]
    public class RegisterActivity : Activity
    {
        TextView txtFirstName;
        TextView txtLastName;
        TextView txtSchool;
        TextView txtUsername;
        TextView txtPassword;
        Button btnRegisterStudent;
        Button btnRegisterTeacher;
        protected override void OnCreate(Bundle savedInstanceState)
        {

            base.OnCreate(savedInstanceState);

            // Create your application here

            SetContentView(Resource.Layout.Register);

            txtFirstName = FindViewById<TextView>(Resource.Id.txtFirstName);
            txtLastName = FindViewById<TextView>(Resource.Id.txtLastName);
            txtSchool = FindViewById<TextView>(Resource.Id.txtSchool);
            txtUsername = FindViewById<TextView>(Resource.Id.txtUsername);
            txtPassword = FindViewById<TextView>(Resource.Id.txtPassword);
            btnRegisterStudent = FindViewById<Button>(Resource.Id.btnRegisterStu);
            btnRegisterTeacher = FindViewById<Button>(Resource.Id.btnRegisterTeach);

            btnRegisterStudent.Click += BtnRegisterStudent_Click;
            btnRegisterTeacher.Click += BtnRegisterTeacher_Click;
        }

        private void BtnRegisterTeacher_Click(object sender, EventArgs e)
        {
            try
            {
                string dpPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "user.db3");
                var db = new SQLiteConnection(dpPath);
                db.CreateTable<LoginTable>();
                LoginTable tbl = new LoginTable();
                tbl.username = txtUsername.Text;
                tbl.password = txtPassword.Text;
                tbl.school = txtSchool.Text;
                tbl.firstName = txtFirstName.Text;
                tbl.lastName = txtLastName.Text;
                tbl.accountType = "Teacher";
                db.Insert(tbl);
                Toast.MakeText(this, "Teacher Added Successfuly", ToastLength.Short).Show();
                var intent = new Intent(this, typeof(LoginTeachActivity));
                StartActivity(intent);
                Finish();
            }
            catch (Exception ex)
            {
                Toast.MakeText(this, ex.ToString(), ToastLength.Short).Show();
            }
            
        }

        private void BtnRegisterStudent_Click(object sender, EventArgs e)
        {
            try
            {
                string dpPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "user.db3");
                var db = new SQLiteConnection(dpPath);
                db.CreateTable<LoginTable>();
                LoginTable tbl = new LoginTable();
                tbl.username = txtUsername.Text;
                tbl.password = txtPassword.Text;
                tbl.school = txtSchool.Text;
                tbl.firstName = txtFirstName.Text;
                tbl.lastName = txtLastName.Text;
                tbl.accountType = "Student";
                db.Insert(tbl);
                Toast.MakeText(this, "Student Added Successfuly", ToastLength.Short).Show();
                var intent = new Intent(this, typeof(LoginStuActivity));
                StartActivity(intent);
                Finish();
            }
            catch (Exception ex)
            {
                Toast.MakeText(this, ex.ToString(), ToastLength.Short).Show();
            }
            
        }
    }
    }
}