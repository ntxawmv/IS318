﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SQLite;

namespace EducationOnTheGo
{
    [Activity(Label = "FirstPageActivity", MainLauncher = true)]
    public class FirstPageActivity : Activity
    {
        Button btnStudent;
        Button btnTeacher;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.FirstPage);

            btnStudent = FindViewById<Button>(Resource.Id.btnStudent);
            btnTeacher = FindViewById<Button>(Resource.Id.btnTeacher);

            btnStudent.Click += BtnStudent_Click;
            btnTeacher.Click += BtnTeacher_Click;

            CreateDB();
        }

        

        private void BtnTeacher_Click(object sender, EventArgs e)
        {
            var intent = new Intent(this, typeof(LoginTeachActivity));
            StartActivity(intent);
            Finish();
        }

        private void BtnStudent_Click(object sender, EventArgs e)
        {
            var intent = new Intent(this, typeof(LoginStuActivity));
            StartActivity(intent);
            Finish();
        }
        public void CreateDB()
        {
            string dpPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "user.db3"); //Create New Database  
            var db = new SQLiteConnection(dpPath);
        }
    }
}